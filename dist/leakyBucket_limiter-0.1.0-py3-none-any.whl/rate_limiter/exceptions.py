class RateLimiterException(Exception):
    pass